import { configureStore } from "@reduxjs/toolkit";
import cartReducer from "./cartSlice.js"; // your cart slice

export const store = configureStore({
  reducer: {
    cart: cartReducer
  }
});