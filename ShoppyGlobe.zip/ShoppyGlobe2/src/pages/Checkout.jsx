import React from "react";
import { useSelector, useDispatch } from "react-redux";
import { clearCart } from "../redux/cartSlice";
import { useNavigate } from "react-router-dom";

function Checkout() {
  const items = useSelector(state => state.cart.items);
  const dispatch = useDispatch();
  const navigate = useNavigate();

  const handleOrder = () => {
    alert("Order placed");
    dispatch(clearCart());
    navigate("/");
  };

  return (
    <div style={{ padding: "20px" }}>
      <h2>Checkout</h2>
      <form>
        <input placeholder="Name" required style={{ display:"block", marginBottom:"10px" }}/>
        <input placeholder="Address" required style={{ display:"block", marginBottom:"10px" }}/>
        <input placeholder="Email" type="email" required style={{ display:"block", marginBottom:"10px" }}/>
      </form>
      <h3>Order Summary:</h3>
      {items.map(item => <p key={item.id}>{item.title} x {item.quantity}</p>)}
      <button onClick={handleOrder}>Place Order</button>
    </div>
  );
}

export default Checkout;