import React, { Suspense } from "react";
const ProductList = React.lazy(() => import("../components/ProductList"));

function Home() {
  return (
    <div style={{ padding: "20px" }}>
      <h1>Welcome to ShoppyGlobe</h1>
      <Suspense fallback={<p>Loading products...</p>}>
        <ProductList />
      </Suspense>
    </div>
  );
}

export default Home;