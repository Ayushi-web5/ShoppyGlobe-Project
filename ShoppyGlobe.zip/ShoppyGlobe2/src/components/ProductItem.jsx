import React from "react";
import { useDispatch } from "react-redux";
import { addToCart } from "../redux/cartSlice";
import { Link } from "react-router-dom";

function ProductItem({ product }) {
  const dispatch = useDispatch();

  return (
    <div style={{ border: "1px solid #ccc", padding: "10px", width: "200px" }}>
      <Link to={`/product/${product.id}`}>
        <img src={product.thumbnail} alt={product.title} width="180" height="150" loading="lazy" />
        <h3>{product.title}</h3>
      </Link>
      <p>${product.price}</p>
      <button onClick={() => dispatch(addToCart(product))}>Add to Cart</button>
    </div>
  );
}

export default ProductItem;