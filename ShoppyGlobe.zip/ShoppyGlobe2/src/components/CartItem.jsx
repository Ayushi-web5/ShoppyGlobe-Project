import React from "react";
import { useDispatch } from "react-redux";
import { removeFromCart, updateQuantity } from "../redux/cartSlice";

function CartItem({ item }) {
  const dispatch = useDispatch();

  return (
    <div style={{ border: "1px solid #ccc", padding: "10px", marginBottom: "10px" }}>
      <p>{item.title}</p>
      <p>${item.price}</p>
      <input
        type="number"
        min="1"
        value={item.quantity}
        onChange={(e) => dispatch(updateQuantity({ id: item.id, quantity: Number(e.target.value) }))}
      />
      <button onClick={() => dispatch(removeFromCart(item.id))}>Remove</button>
    </div>
  );
}

export default CartItem;